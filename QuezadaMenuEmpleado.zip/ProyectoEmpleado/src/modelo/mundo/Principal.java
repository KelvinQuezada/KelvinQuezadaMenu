package modelo.mundo;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Principal {

	static Scanner entrada = new Scanner(System.in);
	public static void main(String[] args) {

		// TODO Auto-generated method stub
		
		//Empleado empleado1;
		Empleado empleado1 = null;	
		String nombreEmple;
		String apellidoEmple;
		int genero; // 1 Femenino || 2 Masculino
		String imagen;
		double salario;
		int dia, mes ,anio;
		Fecha fechaNac;
		Fecha fechaIngreso;
		Scanner sn = new Scanner(System.in);
		int opcion=0;
		do {
		System.out.println("----------        MENU PRINCIPAL         --------");
		System.out.println("1. Ingrese datos del empleado.");
		System.out.println("2. Calcular la edad del empleado");
		System.out.println("3. Calcular la antig�edad del empleado en la empresa");
		System.out.println("4. Calcular las prestaciones del empleado.");
		System.out.println("5. Visualizar la informaci�n del empleado");
		System.out.println("6. SALIR");
		try {
			System.out.println("\nEscoja una de las opciones: ");
			opcion = sn.nextInt();
			}
			catch(InputMismatchException e) { 
				System.out.println("Ingresar solo numeros");
				opcion=6;
				e.printStackTrace();
            	}
            
			switch(opcion){
			case 1:
				System.out.println("***	Registro ***");
				System.out.println("Ingrese su Nombre:");
				nombreEmple= entrada.nextLine();
				System.out.println("Ingrese su Apellido:");
				apellidoEmple= entrada.nextLine();
				System.out.println("Ingrese su Imagen:");
				imagen= entrada.nextLine();
		
				 do {
			        	try {
							System.out.println("Ingrese Genero (1-Femenino, 2-Masculino): ");
							genero= entrada.nextInt();
										
						}
						catch(InputMismatchException e) {
							System.out.println("Debe ingresar solo n�meros ");
							genero = 0;
							entrada.nextInt();
						}
			        }while (genero<1 || genero>2);

				do {
					try {
						System.out.println("Ingrese su Salario entre: (300) hasta (600) ");
				        salario = entrada.nextDouble();
					}
					catch(InputMismatchException e) {
						System.out.println("Ingrese el salario correcto: ");
						salario = 0;
						e.printStackTrace();	
					}
				}while (salario<300 || salario>500);
				
				do {
					System.out.println("Ingrese su Dia de Nacimiento entre :(01) hasta (31) ");
				    dia = entrada.nextInt();
				}while (dia<01 || dia>31);
				
				do {
		        	System.out.println("Ingrese su Mes de Nacimiento entre: (01) hasta (12)");
			        mes = entrada.nextInt();
		        }while (mes<01 || mes>12);
				
				do {
		        	System.out.println("Ingrese su A�o de Nacimiento entre :(1997) hasta (2021)");
			        anio = entrada.nextInt();
			        fechaNac= new Fecha (dia, mes,anio);
		        }while (anio<1997 || anio>2021);
				
				do {
		        	System.out.println("Ingrese Dia de ingreso entre: (01) hasta (31) ");
			        dia = entrada.nextInt();	
		        }while (dia<01 || dia>31);
		        
		        do {
		        	System.out.println("Ingrese Mes de ingreso entre: (01) hasta (12) ");
			        mes = entrada.nextInt();	
		        }while (mes<01 || mes>12);
		        
		        do {
		        	 System.out.println("Ingrese A�o de ingreso: (2000) hasta (2021)");
				      anio = entrada.nextInt();
		        }while (anio<2000 || anio>2021);
				
				fechaIngreso= new Fecha (dia, mes,anio);
                empleado1=new Empleado(nombreEmple, apellidoEmple, genero,imagen, salario, fechaNac, fechaIngreso);
				break;

			case 2:
				
				System.out.println("Su edad es:" +empleado1.calcularEdad());
				break;
				
			case 3:
				
				System.out.println("Su antiguedad en la empresa es:" +empleado1.calcularAntiguedad());
				break;
				
			case 4:
				
				System.out.println("Sus prestaciones son:" +empleado1.calcularPrestaciones());
				break;
				
			case 5:
				System.out.println("=====  Informacion del EMPLEADO  ====");
				empleado1.mostrarInformaic�n();
				break;
				
			case 6:
				System.out.println("Finaliza el Programa");
				break;

			default:
				System.out.println("Opcion Incorrecta ingrese del (1) al (6)");
			}
		}while(opcion!=6);
	
	}	
}
